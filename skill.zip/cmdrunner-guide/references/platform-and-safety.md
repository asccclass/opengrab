# cmdrunner platform and safety notes

## Scope
This file exists to keep answers about `cmdrunner` accurate and conservative.

## Prefer `ModeArgs`
Recommend `ModeArgs` by default because:
- it avoids shell parsing
- it is safer for untrusted input
- it is more suitable for production services
- it keeps argument boundaries explicit

Do not recommend `ModeShell` unless the command actually requires shell features.

## Require `ModeShell` only for shell syntax
Use `ModeShell` when the command contains or depends on:
- redirection like `>` or `>>`
- pipes like `|`
- command chaining like `&&` or `||`
- wildcard expansion
- shell builtins
- shell-specific expressions

When using `ModeShell`, explain briefly that `cmdrunner` will choose:
- `cmd /C` on Windows
- `sh -c` on non-Windows

## Cross-platform caution
Automatic shell selection does not make every shell command string portable.

Examples:
- reading a file can differ across platforms
- truncating a file can differ across platforms
- quoting behavior can differ
- shell builtins can differ

If the user asks for a shell command example that touches the filesystem, mention that the shell command string may still need OS-specific adjustment.

## File operations
If the user wants only to create, append, overwrite, or read files, say that direct Go file APIs are safer and more portable than shell commands. Still provide the `cmdrunner` example if the user specifically asked for `cmdrunner`.

## Process control guidance
Use `Start` instead of `RunAsync` when the user needs:
- pid
- signal handling
- graceful stop
- hard kill
- timeout waiting
- restart control

Use `Supervisor` instead of plain `Process` only when the user needs:
- automatic restart
- bounded retries
- backoff
- health checks
- log retention
- metrics
- prometheus integration

## Monitoring guidance
Use `SnapshotMetrics()` for programmatic inspection inside the same process.

Use `PrometheusText(...)` or `PrometheusHandler(...)` for monitoring integration.

Do not expose high-cardinality strings like arbitrary error messages as Prometheus labels. Prefer fixed labels such as:
- service
- env
- instance

## Answering rules
- Stay specific to `cmdrunner`.
- Prefer one correct pattern over many options.
- Do not invent helper APIs that do not exist.
- Do not claim shell-based patterns are safer than args-based patterns.
- Do not turn every answer into a supervisor example.
- Do not recommend Prometheus unless the user is asking about monitoring or metrics.
