# cmdrunner api cheatsheet

## Execution modes

### `ModeArgs`
Use for normal executable invocation without shell parsing.

Typical fields:
```go
cmdrunner.Options{
    Mode:    cmdrunner.ModeArgs,
    Program: "go",
    Args:    []string{"version"},
}
```

Use when:
- running a binary directly
- passing arguments safely
- avoiding shell injection risks
- building production examples

Do not use when the command requires shell operators like `>`, `|`, or `&&`.

### `ModeShell`
Use when the command string depends on shell syntax.

Typical fields:
```go
cmdrunner.Options{
    Mode:         cmdrunner.ModeShell,
    ShellCommand: `echo "1234567" > example.txt`,
}
```

Use when:
- redirecting output
- piping commands
- chaining with `&&` or `||`
- using shell builtins or expansions

`cmdrunner` automatically selects:
- Windows: `cmd /C`
- non-Windows: `sh -c`

## One-off execution

### `Run`
Use for synchronous execution.

Pattern:
```go
res, err := cmdrunner.Run(context.Background(), cmdrunner.Options{
    Mode:    cmdrunner.ModeArgs,
    Program: "go",
    Args:    []string{"version"},
})
```

Use when:
- the command is short-lived
- the caller can wait for completion
- only one result is needed

### `RunAsync`
Use for asynchronous execution with a result channel.

Pattern:
```go
handle := cmdrunner.RunAsync(context.Background(), cmdrunner.Options{
    Mode:    cmdrunner.ModeArgs,
    Program: "go",
    Args:    []string{"env", "GOVERSION"},
})

done := <-handle.ResultChan
```

Use when:
- the caller wants non-blocking start
- channel-based result delivery is enough
- process lifecycle control is not the main requirement

## Process control

### `Start`
Use for long-running processes and explicit lifecycle control.

Pattern:
```go
proc, err := cmdrunner.Start(context.Background(), cmdrunner.Options{
    Mode:    cmdrunner.ModeArgs,
    Program: "sleep",
    Args:    []string{"100"},
})
```

### `Process` methods
Use these after `Start(...)`:
- `PID()`
- `IsRunning()`
- `Wait()`
- `WaitTimeout(d)`
- `Done()`
- `Signal(sig)`
- `GracefulStop(timeout)`
- `Kill()`
- `Restart()`

Use `Start` instead of `RunAsync` when the user needs:
- PID access
- graceful shutdown
- hard kill
- timeout waiting
- restart control

## I/O features

### `Stdin`
Use `Options.Stdin` to send input.

Pattern:
```go
cmdrunner.Options{
    Mode:    cmdrunner.ModeArgs,
    Program: "sort",
    Stdin:   strings.NewReader("c\nb\na\n"),
}
```

### live stdout/stderr
Use `Options.Stdout` and `Options.Stderr`.

Pattern:
```go
cmdrunner.Options{
    Mode:    cmdrunner.ModeArgs,
    Program: "go",
    Args:    []string{"version"},
    Stdout:  os.Stdout,
    Stderr:  os.Stderr,
}
```

Explain that streamed output is still captured in `Result.Stdout` and `Result.Stderr`.

## Supervisor

### `NewSupervisor`
Use for production-style supervision.

Pattern:
```go
sv, err := cmdrunner.NewSupervisor(cmdrunner.SupervisorOptions{
    Process: cmdrunner.Options{
        Mode:    cmdrunner.ModeArgs,
        Program: "my-worker",
    },
    RestartPolicy: cmdrunner.RestartPolicyOnFailure,
    MaxRestarts:   10,
    Backoff:       cmdrunner.ExponentialBackoff(time.Second, 30*time.Second),
})
```

### restart policy
Use one of:
- `RestartPolicyNever`
- `RestartPolicyAlways`
- `RestartPolicyOnFailure`

### backoff
Use one of:
- `FixedBackoff(d)`
- `ExponentialBackoff(base, max)`
- `JitterBackoff(baseBackoff, ratio)`

### health checks
Relevant fields:
- `HealthCheck`
- `HealthCheckInterval`
- `HealthCheckTimeout`
- `HealthCheckFailures`
- `HealthCheckStopTimeout`

### logs
Relevant fields:
- `RingBufferBytes`
- `LogRotate`

### hooks
Relevant fields:
- `BeforeStart`
- `AfterStop`

## Metrics and monitoring

### in-process metrics
Use:
```go
m := sv.SnapshotMetrics()
```

### Prometheus text
Use:
```go
text := sv.PrometheusText("cmdrunner", map[string]string{
    "service": "demo-worker",
    "env":     "prod",
})
```

### HTTP handler
Use:
```go
http.HandleFunc("/metrics", sv.PrometheusHandler("cmdrunner", map[string]string{
    "service": "demo-worker",
}))
```

## Decision table

### User asks for a direct command example
Use `Run`.

### User asks for background execution but not lifecycle control
Use `RunAsync`.

### User asks for start, stop, signal, kill, or PID
Use `Start` and `Process`.

### User asks for restart policy, health checks, metrics, or automatic recovery
Use `Supervisor`.

### User gives a shell command with `>`, `|`, or `&&`
Use `ModeShell`.

### User only needs safe executable invocation
Use `ModeArgs`.
