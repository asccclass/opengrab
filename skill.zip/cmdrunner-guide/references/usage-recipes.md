# cmdrunner usage recipes

## Recipe: run a normal command safely with `ModeArgs`

```go
package main

import (
    "context"
    "fmt"

    "your_project/cmdrunner"
)

func main() {
    res, err := cmdrunner.Run(context.Background(), cmdrunner.Options{
        Mode:    cmdrunner.ModeArgs,
        Program: "go",
        Args:    []string{"version"},
    })

    fmt.Println("exitCode:", res.ExitCode)
    fmt.Println("stdout:", res.Stdout)
    fmt.Println("stderr:", res.Stderr)
    fmt.Println("err:", err)
}
```

Use this recipe first unless shell syntax is required.

---

## Recipe: convert a shell redirection command

User intent:
```sh
echo "1234567" > example.txt
```

Use:
```go
package main

import (
    "context"
    "fmt"

    "your_project/cmdrunner"
)

func main() {
    res, err := cmdrunner.Run(context.Background(), cmdrunner.Options{
        Mode:         cmdrunner.ModeShell,
        ShellCommand: `echo "1234567" > example.txt`,
    })

    fmt.Println("exitCode:", res.ExitCode)
    fmt.Println("stderr:", res.Stderr)
    fmt.Println("err:", err)
}
```

Explain that `ModeShell` is required because `>` is shell syntax.

---

## Recipe: pass stdin

```go
package main

import (
    "context"
    "fmt"
    "strings"

    "your_project/cmdrunner"
)

func main() {
    res, err := cmdrunner.Run(context.Background(), cmdrunner.Options{
        Mode:    cmdrunner.ModeArgs,
        Program: "sort",
        Stdin:   strings.NewReader("c\nb\na\n"),
    })

    fmt.Println("stdout:", res.Stdout)
    fmt.Println("err:", err)
}
```

---

## Recipe: stream stdout and stderr live

```go
package main

import (
    "context"
    "os"

    "your_project/cmdrunner"
)

func main() {
    _, _ = cmdrunner.Run(context.Background(), cmdrunner.Options{
        Mode:    cmdrunner.ModeArgs,
        Program: "go",
        Args:    []string{"version"},
        Stdout:  os.Stdout,
        Stderr:  os.Stderr,
    })
}
```

Use this when the user wants real-time output.

---

## Recipe: start a process and wait later

```go
package main

import (
    "context"
    "fmt"

    "your_project/cmdrunner"
)

func main() {
    proc, err := cmdrunner.Start(context.Background(), cmdrunner.Options{
        Mode:    cmdrunner.ModeArgs,
        Program: "sleep",
        Args:    []string{"5"},
    })
    if err != nil {
        panic(err)
    }

    fmt.Println("pid:", proc.PID())
    fmt.Println("running:", proc.IsRunning())

    res, err := proc.Wait()
    fmt.Println("exitCode:", res.ExitCode)
    fmt.Println("err:", err)
}
```

Use this when the user needs lifecycle control.

---

## Recipe: graceful stop then hard kill fallback

```go
package main

import (
    "context"
    "fmt"
    "time"

    "your_project/cmdrunner"
)

func main() {
    proc, err := cmdrunner.Start(context.Background(), cmdrunner.Options{
        Mode:    cmdrunner.ModeArgs,
        Program: "sleep",
        Args:    []string{"100"},
    })
    if err != nil {
        panic(err)
    }

    time.Sleep(2 * time.Second)

    if err := proc.GracefulStop(3 * time.Second); err != nil {
        fmt.Println("graceful stop err:", err)
    }

    res, err := proc.Wait()
    fmt.Println("exitCode:", res.ExitCode)
    fmt.Println("err:", err)
}
```

---

## Recipe: supervisor with restart policy

```go
package main

import (
    "context"
    "time"

    "your_project/cmdrunner"
)

func main() {
    sv, err := cmdrunner.NewSupervisor(cmdrunner.SupervisorOptions{
        Process: cmdrunner.Options{
            Mode:    cmdrunner.ModeArgs,
            Program: "my-worker",
        },
        RestartPolicy: cmdrunner.RestartPolicyOnFailure,
        MaxRestarts:   10,
        Backoff: cmdrunner.JitterBackoff(
            cmdrunner.ExponentialBackoff(1*time.Second, 30*time.Second),
            0.2,
        ),
    })
    if err != nil {
        panic(err)
    }

    if err := sv.Start(context.Background()); err != nil {
        panic(err)
    }

    _ = sv.Wait()
}
```

Use this only when the user needs actual supervision.

---

## Recipe: supervisor with health checks

```go
package main

import (
    "context"
    "net"
    "time"

    "your_project/cmdrunner"
)

func main() {
    sv, err := cmdrunner.NewSupervisor(cmdrunner.SupervisorOptions{
        Process: cmdrunner.Options{
            Mode:    cmdrunner.ModeArgs,
            Program: "my-server",
        },
        RestartPolicy:          cmdrunner.RestartPolicyOnFailure,
        HealthCheckInterval:    5 * time.Second,
        HealthCheckTimeout:     2 * time.Second,
        HealthCheckFailures:    3,
        HealthCheckStopTimeout: 3 * time.Second,
        HealthCheck: func(ctx context.Context, p *cmdrunner.Process) error {
            d := net.Dialer{Timeout: 1 * time.Second}
            conn, err := d.DialContext(ctx, "tcp", "127.0.0.1:8080")
            if err != nil {
                return err
            }
            _ = conn.Close()
            return nil
        },
    })
    if err != nil {
        panic(err)
    }

    if err := sv.Start(context.Background()); err != nil {
        panic(err)
    }

    _ = sv.Wait()
}
```

---

## Recipe: expose Prometheus metrics

```go
package main

import (
    "context"
    "fmt"
    "net/http"
    "time"

    "your_project/cmdrunner"
)

func main() {
    sv, err := cmdrunner.NewSupervisor(cmdrunner.SupervisorOptions{
        Process: cmdrunner.Options{
            Mode:    cmdrunner.ModeArgs,
            Program: "sleep",
            Args:    []string{"1000"},
        },
        RestartPolicy: cmdrunner.RestartPolicyOnFailure,
        MaxRestarts:   10,
        Backoff: cmdrunner.JitterBackoff(
            cmdrunner.ExponentialBackoff(1*time.Second, 30*time.Second),
            0.2,
        ),
    })
    if err != nil {
        panic(err)
    }

    if err := sv.Start(context.Background()); err != nil {
        panic(err)
    }

    http.HandleFunc("/metrics", sv.PrometheusHandler("cmdrunner", map[string]string{
        "service": "demo-worker",
        "env":     "prod",
    }))

    fmt.Println("listen on :8080")
    panic(http.ListenAndServe(":8080", nil))
}
```

---

## Recipe: inspect metrics in process

```go
m := sv.SnapshotMetrics()
fmt.Println("running:", m.Running)
fmt.Println("restarts:", m.Restarts)
fmt.Println("crashes:", m.Crashes)
fmt.Println("current uptime:", m.CurrentUptime)
fmt.Println("last restart reason:", m.LastRestartReason)
```
