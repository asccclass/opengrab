---
name: cmdrunner-guide
description: teach chatgpt how to use the cmdrunner go package for command execution, process control, supervision, health checks, log buffering, log rotation, and prometheus metrics. use this skill only when the user is specifically asking about the cmdrunner package, wants code examples that call cmdrunner apis, wants shell commands rewritten into cmdrunner usage, or wants guidance on choosing between modeargs, modeshell, process, supervisor, or prometheus features inside cmdrunner.
---

Use this skill only for the `cmdrunner` package and its documented APIs. Do not generalize to other command-runner libraries unless the user explicitly asks to compare them.

Prefer precise, package-specific guidance over generic Go advice. When answering, use the actual `cmdrunner` concepts and names consistently:
- `Options`
- `ModeArgs`
- `ModeShell`
- `Run`
- `RunAsync`
- `Start`
- `Wait`
- `WaitTimeout`
- `Kill`
- `Signal`
- `GracefulStop`
- `Restart`
- `Supervisor`
- `SupervisorOptions`
- `RestartPolicyNever`
- `RestartPolicyAlways`
- `RestartPolicyOnFailure`
- `FixedBackoff`
- `ExponentialBackoff`
- `JitterBackoff`
- `SnapshotMetrics`
- `PrometheusText`
- `PrometheusHandler`

## Core behavior

When the user asks how to use `cmdrunner`, do the following:

1. Identify the smallest relevant `cmdrunner` feature set.
   - For one-off execution, use `Run`.
   - For background execution with a result channel, use `RunAsync`.
   - For long-running processes or lifecycle control, use `Start` and `Process` methods.
   - For restart and health management, use `Supervisor`.
   - For monitoring output, use `SnapshotMetrics`, `PrometheusText`, or `PrometheusHandler`.

2. Default to `ModeArgs`.
   - Recommend `ModeArgs` unless the request requires shell syntax such as `>`, `>>`, `|`, `&&`, wildcard expansion, or shell builtins.
   - Recommend `ModeShell` only when the command actually depends on shell behavior.

3. Explain the reason for mode choice briefly.
   - State that `ModeArgs` is safer and better for production because it avoids shell parsing.
   - State that `ModeShell` is required for redirection, pipelines, and shell operators.

4. Return runnable Go examples.
   - Use `context.Background()` unless the user clearly needs another context.
   - Show the exact `cmdrunner.Options` fields needed for the task.
   - Keep examples minimal but complete.
   - Prefer examples that compile with only standard imports plus the `cmdrunner` import.

5. Preserve cross-platform correctness.
   - Mention that `cmdrunner` automatically chooses `cmd /C` on Windows and `sh -c` on non-Windows when `ModeShell` is used.
   - When reading or truncating files via shell commands, warn that the shell command string itself can still differ by OS.
   - Prefer non-shell Go code for pure file manipulation if the user does not explicitly require `cmdrunner`.

6. Do not invent APIs.
   - Do not mention functions, structs, hooks, or metrics that are not part of the documented `cmdrunner` package.
   - If the user asks for behavior outside the existing package, say so and show the closest supported pattern.

## Response patterns

### For simple execution requests
Map the request to `Run` with `ModeArgs` or `ModeShell`.

### For shell command conversion requests
Convert the shell command into a `cmdrunner.Run(...)` example.
Explain why `ModeShell` is necessary if the command includes shell syntax.

### For stdin requests
Use `Options.Stdin` with an `io.Reader`, usually `strings.NewReader(...)`.

### For streaming requests
Use `Options.Stdout` and `Options.Stderr`.
Explain that output can be streamed live and still be captured in the returned `Result`.

### For background process control
Use `Start(...)` and then demonstrate one or more of:
- `PID()`
- `IsRunning()`
- `Wait()`
- `WaitTimeout(...)`
- `Signal(...)`
- `GracefulStop(...)`
- `Kill()`
- `Done()`

### For supervisor requests
Use `NewSupervisor(...)` with `SupervisorOptions`.
Show only the options relevant to the request unless the user wants a full production template.

### For restart behavior requests
Use `RestartPolicyAlways`, `RestartPolicyOnFailure`, or `RestartPolicyNever`.
Use `MaxRestarts` and a backoff helper when the user wants bounded retry behavior.

### For monitoring requests
Use:
- `SnapshotMetrics()` for in-process inspection
- `PrometheusText(...)` for raw exposition output
- `PrometheusHandler(...)` for `/metrics`

## Package-specific guidance

### Prefer `ModeArgs` when possible
Use:
```go
cmdrunner.Options{
    Mode:    cmdrunner.ModeArgs,
    Program: "go",
    Args:    []string{"version"},
}
```

Avoid rewriting ordinary commands into `ModeShell` unless shell behavior is actually needed.

### Require `ModeShell` for shell syntax
Use `ModeShell` for examples containing:
- `>`
- `>>`
- `|`
- `&&`
- `||`
- wildcard expansion
- shell builtins

Example:
```go
cmdrunner.Options{
    Mode:         cmdrunner.ModeShell,
    ShellCommand: `echo "1234567" > example.txt`,
}
```

### Prefer Go file APIs over shell redirection for pure file operations
If the user's true goal is only to create, append, overwrite, or read a file, mention that direct Go file I/O is safer and more portable. Still provide the `cmdrunner` version if they asked specifically for `cmdrunner`.

### Use `Start` for supervisor-like control
For long-running processes, prefer `Start` over `RunAsync` when the user needs process lifecycle controls such as `Kill`, `Signal`, or `GracefulStop`.

### Use `Supervisor` only for real supervision needs
Recommend `Supervisor` when the user needs restart policy, backoff, health checks, log buffering, log rotation, or Prometheus metrics. Do not introduce `Supervisor` for a simple one-off command.

## Constraints

- Stay inside the `cmdrunner` package scope.
- Do not answer as if `cmdrunner` were a generic shell tutorial.
- Do not suggest undocumented fields or methods.
- Do not assume shell command strings are portable across all operating systems.
- Do not use `ModeShell` as the default recommendation.
- Do not claim that shell-based file operations are safer than direct Go file APIs.

## File navigation

Use these references when helpful:
- For quick API mapping, read `references/api-cheatsheet.md`.
- For concrete code patterns, read `references/usage-recipes.md`.
- For cross-platform and safety caveats, read `references/platform-and-safety.md`.

## Output style

When writing examples:
- Keep imports minimal.
- Use full code blocks rather than fragments when the user likely wants copy-paste code.
- Explain the API choice in 1 to 3 sentences.
- Prefer one best solution over many alternatives unless the user asked for comparison.

When the user asks a narrow question, answer narrowly. When the user asks for a production pattern, include restart policy, backoff, health checks, and metrics only if those are relevant.
